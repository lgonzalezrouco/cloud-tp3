# lambda-src/create_product/app.py
import json, os
import pg8000.native as pg

def _conn():
    return pg.Connection(
        user=os.environ["PGUSER"], password=os.environ["PGPASSWORD"],
        host=os.environ["PGHOST"], port=int(os.environ.get("PGPORT","5432")),
        database=os.environ["PGDATABASE"], ssl_context=True
    )

def _resp(code, payload): return {"statusCode": code, "body": json.dumps(payload, default=str)}
def _claims(event):
    rc = event.get("requestContext", {})
    auth = (rc.get("authorizer") or {}).get("jwt") or {}
    return auth.get("claims") or {}

def handler(event, context):
    try:
        claims = _claims(event)
        email  = (claims.get("email") or "").strip().lower()
        if not email:
            return _resp(401, {"error":"unauthorized"})

        body = json.loads(event.get("body") or "{}")
        name        = (body.get("name") or "").strip()
        description = body.get("description")
        category    = (body.get("category") or "").strip()
        price       = body.get("price")
        image_url   = body.get("image_url")

        if not name or not category or price is None:
            return _resp(400, {"error":"name, category y price son obligatorios"})
        try:
            price = float(price)
        except Exception:
            return _resp(400, {"error":"price debe ser numérico"})

        with _conn() as conn:
            seller = conn.run("SELECT id, first_name, last_name, is_seller FROM users WHERE email = :email", email=email)
            if not seller:
                return _resp(403, {"error":"usuario no registrado en users"})
            seller_id, fn, ln, is_seller = seller[0]
            if not is_seller:
                return _resp(403, {"error":"el usuario no es seller"})

            row = conn.run("""
              INSERT INTO products (name, description, category, seller_id, image_url, price)
              VALUES (:name, :description, :category, :seller_id, :image_url, :price)
              RETURNING id, name, description, category, price, image_url, paused, deleted, seller_id
            """, name=name, description=description, category=category,
                 seller_id=seller_id, image_url=image_url, price=price)[0]

        product = {
            "id": row[0], "name": row[1], "description": row[2], "category": row[3],
            "price": float(row[4]), "image_url": row[5], "paused": row[6], "deleted": row[7],
            "seller_id": row[8], "first_name": fn, "last_name": ln
        }
        return _resp(201, {"product": product, "message":"Product created successfully"})
    except Exception as e:
        print("ERROR create_product:", e)
        return _resp(500, {"error":"DB error", "detail": str(e)})
