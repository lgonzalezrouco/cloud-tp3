# lambda-src/create_store/app.py
import json, os
import pg8000.native as pg

def _conn():
    return pg.Connection(
        user=os.environ["PGUSER"], password=os.environ["PGPASSWORD"],
        host=os.environ["PGHOST"], port=int(os.environ.get("PGPORT","5432")),
        database=os.environ["PGDATABASE"], ssl_context=True
    )

def _resp(code, payload): return {"statusCode": code, "body": json.dumps(payload, default=str)}
def _claims(event):
    rc = event.get("requestContext", {})
    auth = (rc.get("authorizer") or {}).get("jwt") or {}
    return auth.get("claims") or {}

def handler(event, context):
    try:
        claims = _claims(event)
        email  = (claims.get("email") or "").strip().lower()
        if not email:
            return _resp(401, {"error":"unauthorized"})

        body = json.loads(event.get("body") or "{}")
        store_name      = body.get("store_name")
        description     = body.get("description")
        store_image_url = body.get("store_image_url")
        cover_image_url = body.get("cover_image_url")
        cbu             = body.get("cbu")

        with _conn() as conn:
            u = conn.run("SELECT id, is_seller FROM users WHERE email = :email", email=email)
            if not u:
                return _resp(403, {"error":"usuario no registrado"})
            user_id, is_seller = u[0]
            if not is_seller:
                return _resp(403, {"error":"el usuario no es seller"})

            row = conn.run("""
              INSERT INTO stores (store_id, store_name, description, store_image_url, cover_image_url, cbu)
              VALUES (:store_id, :store_name, :description, :store_image_url, :cover_image_url, :cbu)
              RETURNING store_id, store_name, description, store_image_url, cover_image_url, cbu
            """, store_id=user_id, store_name=store_name, description=description,
                 store_image_url=store_image_url, cover_image_url=cover_image_url, cbu=cbu)[0]

        keys = ["store_id","store_name","description","store_image_url","cover_image_url","cbu"]
        return _resp(201, dict(zip(keys, row)))
    except Exception as e:
        sqlstate = getattr(e, "sqlstate", None) or getattr(e, "code", None)
        if sqlstate == "23505":
            return _resp(409, {"error":"ya existe una store para el usuario"})
        print("ERROR create_store:", e)
        return _resp(500, {"error":"DB error", "detail": str(e)})
