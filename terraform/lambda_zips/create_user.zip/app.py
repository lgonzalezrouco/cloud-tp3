import json, os, re
import pg8000.native as pg

EMAIL_RX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def _conn():
    return pg.Connection(
        user=os.environ["PGUSER"], password=os.environ["PGPASSWORD"],
        host=os.environ["PGHOST"], port=int(os.environ.get("PGPORT","5432")),
        database=os.environ["PGDATABASE"], ssl_context=True
    )

def _resp(code, payload): return {"statusCode": code, "body": json.dumps(payload, default=str)}
def _claims(event):
    rc = event.get("requestContext", {})
    auth = (rc.get("authorizer") or {}).get("jwt") or {}
    return auth.get("claims") or {}

def handler(event, context):
    try:
        claims = _claims(event)
        email          = (claims.get("email") or "").strip()
        cognito_sub    = claims.get("sub")
        email_verified = str(claims.get("email_verified", "false")).lower() == "true"
        if not email or not EMAIL_RX.match(email):
            return _resp(401, {"error": "token sin email válido"})
        if not cognito_sub:
            return _resp(401, {"error": "token sin sub (cognito_sub)"})

        body       = json.loads(event.get("body") or "{}")
        phone      = body.get("phone")
        first_name = body.get("first_name")
        last_name  = body.get("last_name")
        is_seller  = bool(body.get("is_seller", False))
        is_active  = bool(body.get("is_active", True))
        locale     = body.get("locale") or "en"
        address    = body.get("address") or ""

        with _conn() as conn:
            row = conn.run("""
              INSERT INTO users (email, cognito_sub, email_verified, phone, first_name, last_name,
                                 is_seller, is_active, locale, address)
              VALUES (:email, :cognito_sub, :email_verified, :phone, :first_name, :last_name,
                      :is_seller, :is_active, :locale, :address)
              ON CONFLICT (email) DO UPDATE SET
                cognito_sub    = EXCLUDED.cognito_sub,
                email_verified = EXCLUDED.email_verified,
                phone          = EXCLUDED.phone,
                first_name     = EXCLUDED.first_name,
                last_name      = EXCLUDED.last_name,
                is_seller      = EXCLUDED.is_seller,
                is_active      = EXCLUDED.is_active,
                locale         = EXCLUDED.locale,
                address        = EXCLUDED.address,
                updated_at     = now()
              RETURNING id, email, cognito_sub, email_verified, phone, first_name, last_name,
                        is_seller, is_active, locale, address
            """, email=email, cognito_sub=cognito_sub, email_verified=email_verified,
                 phone=phone, first_name=first_name, last_name=last_name,
                 is_seller=is_seller, is_active=is_active, locale=locale, address=address)[0]

        keys = ["id","email","cognito_sub","email_verified","phone","first_name","last_name",
                "is_seller","is_active","locale","address"]
        return _resp(201, dict(zip(keys, row)))
    except Exception as e:
        print("ERROR create_user:", e)
        return _resp(500, {"error":"DB error","detail":str(e)})
