# lambda-src/get_product/app.py
import json, os
import pg8000.native as pg

def _conn():
    return pg.Connection(
        user=os.environ["PGUSER"], password=os.environ["PGPASSWORD"],
        host=os.environ["PGHOST"], port=int(os.environ.get("PGPORT","5432")),
        database=os.environ["PGDATABASE"], ssl_context=True
    )

def handler(event, context):
    try:
        pid = event.get("pathParameters", {}).get("id")
        if not pid:
            return {"statusCode": 400, "body": json.dumps({"error":"missing id"})}

        with _conn() as conn:
            row = conn.run("""
              SELECT
                p.id, p.name, p.description, p.category, p.price, p.image_url,
                p.paused, p.deleted, p.seller_id,
                u.first_name, u.last_name
              FROM products p
              LEFT JOIN users u ON u.id = p.seller_id
              WHERE p.id = :id
            """, id=int(pid))
            if not row:
                return {"statusCode": 404, "body": json.dumps({"error":"not found"})}
            r = row[0]
            product = {
                "id": r[0], "name": r[1], "description": r[2], "category": r[3],
                "price": float(r[4]), "image_url": r[5], "paused": r[6], "deleted": r[7],
                "seller_id": r[8], "first_name": r[9], "last_name": r[10]
            }
        return {"statusCode": 200, "body": json.dumps({"product": product}, default=str)}
    except Exception as e:
        print("ERROR get_product:", e)
        return {"statusCode": 500, "body": json.dumps({"error":"DB error","detail":str(e)})}
