import os
import pg8000.native as pg

def _conn():
    return pg.Connection(
        user=os.environ["PGUSER"], password=os.environ["PGPASSWORD"],
        host=os.environ["PGHOST"], port=int(os.environ.get("PGPORT","5432")),
        database=os.environ["PGDATABASE"], ssl_context=True
    )

def handler(event, context):
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with open(schema_path, "r", encoding="utf-8") as f:
        sql = f.read()
    stmts = [s.strip() for s in sql.split(";") if s.strip()]
    applied = 0
    with _conn() as conn:
        for s in stmts:
            conn.run(s)
            applied += 1
    return {"statusCode": 200, "body": f"Schema applied. Statements executed: {applied}"}
