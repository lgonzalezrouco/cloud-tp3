# lambda-src/list_products/app.py
import json, os, math
import pg8000.native as pg

def _conn():
    return pg.Connection(
        user=os.environ["PGUSER"], password=os.environ["PGPASSWORD"],
        host=os.environ["PGHOST"], port=int(os.environ.get("PGPORT","5432")),
        database=os.environ["PGDATABASE"], ssl_context=True
    )

def handler(event, context):
    try:
        qs = event.get("queryStringParameters") or {}
        category  = qs.get("category")
        seller_id = qs.get("seller_id")
        q         = qs.get("q")
        # paginación
        page  = max(int(qs.get("page", 1)), 1)
        limit = min(max(int(qs.get("limit", 10)), 1), 100)
        offset = (page - 1) * limit

        conds, params = [], {}
        if category:
            conds.append("p.category = :category")
            params["category"] = category
        if seller_id:
            conds.append("p.seller_id = :seller_id")
            params["seller_id"] = int(seller_id)
        if q:
            conds.append("p.name ILIKE :q")
            params["q"] = f"%{q}%"

        where = (" WHERE " + " AND ".join(conds)) if conds else ""

        sql_count = f"SELECT COUNT(*) FROM products p{where}"
        sql_rows = f"""
          SELECT
            p.id, p.name, p.description, p.category, p.price, p.image_url,
            p.paused, p.deleted, p.seller_id,
            u.first_name, u.last_name
          FROM products p
          LEFT JOIN users u ON u.id = p.seller_id
          {where}
          ORDER BY p.id DESC
          LIMIT :limit OFFSET :offset
        """

        with _conn() as conn:
            total = conn.run(sql_count, **params)[0][0]
            rows  = conn.run(sql_rows, **params, limit=limit, offset=offset)

        products = []
        for r in rows:
            (pid, name, desc, cat, price, img, paused, deleted, sid, fn, ln) = r
            products.append({
                "id": pid,
                "name": name,
                "description": desc,
                "category": cat,
                "price": float(price),
                "image_url": img,
                "paused": paused,
                "seller_id": sid,
                "first_name": fn,
                "last_name": ln
            })

        total_pages = math.ceil(total / limit) if limit else 1
        pagination = {
            "page": page,
            "limit": limit,
            "total": total,
            "totalPages": total_pages,
            "hasNext": page < total_pages,
            "hasPrev": page > 1
        }

        body = { "products": products, "pagination": pagination }
        return {"statusCode": 200, "body": json.dumps(body, default=str)}

    except Exception as e:
        print("ERROR list_products:", e)
        body = { "products": [], "pagination": { "page":1,"limit":limit, "total":0, "totalPages":0, "hasNext":False, "hasPrev":False } }
        return {"statusCode": 500, "body": json.dumps({"error":"DB error","detail":str(e), **body})}
